import pandas as pd
import matplotlib.pyplot as plt
import math
import numpy as np
from IPython.display import display



def matrix_minor(arr, i, j):
    return np.delete(np.delete(arr, i, axis=0), j, axis=1)
def r_partial(arr, i,j):
    aij = (-1)**(i+j)*np.linalg.det(matrix_minor(np.array(arr), i, j))
    aii = np.linalg.det(matrix_minor(np.array(arr), i, i))
    ajj = np.linalg.det(matrix_minor(np.array(arr), j, j))
    return -aij/math.sqrt(aii*ajj)
def corr_partial(arr):
    res = np.copy(arr)
    for i in range(np.shape(arr)[0]):
        for j in range(np.shape(arr)[0]):
            if i != j:
                res[i, j] = r_partial(arr, i, j)
            else:
                res[i, j] =-r_partial(arr, i, j)
    res=pd.DataFrame(res)
    res.index=arr.index; res.columns = arr.columns
    return res

value_mass = []
frequency = {}
df = pd.read_csv('8.csv')

# датасет из первого блока
oldGG = (plt.hist(df['W7_2015']))
oldGroup = [list(oldGG[0]), list(oldGG[1])]
plt.show()
# новый датасет
gg = (plt.hist(df['W2_2014']))
group = [list(gg[0]), list(gg[1])]
plt.show()

st_group = pd.DataFrame(columns = ["Внут.средняя",  "Внутригрупповая дисперсия", "Вес группы", "Коэф.вар."])
data_group = []
for i in range(len(group[0])):
    data_group.append(df[(group[1][i] <= df['W1_2014']) & (df['W1_2014'] <= group[1][i + 1])]['W2_2014'])
    Avg_in = data_group[i].mean()
    D_in=data_group[i].std()**2
    Kv_in = math.sqrt(D_in)/Avg_in*100
    st_group = st_group.append(pd.Series([Avg_in, D_in, len(data_group[i]), Kv_in], index=st_group.columns), ignore_index=True)

D = df['W2_2014'].std()**2
Mean = df['W2_2014'].mean()
D_out = (((st_group['Внут.средняя']-Mean)**2)*st_group['Вес группы']).sum()/st_group['Вес группы'].sum()

# эмпирическое корреляционное отношение
cor_relation = math.sqrt(D_out/D)
print(f'Данные посчитаны для W2_2014\n'
      f'Эмпирическое корреляционное отношение: {cor_relation}')


# сравнения распределения с нормальным распределением
fig, ax = plt.subplots()
percs = np.linspace(0, 100, 21)
qn_a = np.percentile(oldGroup[1], percs)
qn_b = np.percentile(group[1], percs)
ax.plot(qn_a, qn_b, ls="", marker="o")
x = np.linspace(np.min((qn_a.min(), qn_b.min())), np.max((qn_a.max(), qn_b.max())))
ax.plot(x, x, color="k", ls="--")
ax.set_title('График КК')
plt.show()


print(f'Так как коэффициент больше 0.8 то эти отношения сильные\n'
      f'{np.corrcoef(oldGroup[0], group[0])}')


# Расчет частного коэффициента корреляции
myDataOld = pd.DataFrame(oldGroup[0])
myData = pd.DataFrame(group[0])
corr = myData.corr()
corr.style.background_gradient()
corrOld = myDataOld.corr()
corrOld.style.background_gradient()
display(pd.DataFrame(corr_partial(corr)).style.background_gradient(cmap='plasma').set_precision(2))
display(pd.DataFrame(corr_partial(corrOld)).style.background_gradient(cmap='plasma').set_precision(2))


# Расчет ранговых коэффициентов корреляции Спирмена
corr = myData.corr("spearman")
corr.style.background_gradient()
corr = myDataOld.corr("spearman")
corr.style.background_gradient()

# Расчет ранговых коэффициентов корреляции Кендала
corr = myData.corr("kendall")
corr.style.background_gradient()
corr = myDataOld.corr("kendall")
corr.style.background_gradient()






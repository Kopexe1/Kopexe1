import numpy as np
import pandas as pd
import statistics as s
import matplotlib.pyplot as plt
from scipy.stats import variation, skew, kurtosis
import seaborn as sns


def geo_mean(iterable):
    a = np.array(iterable)
    return a.prod()**(1.0/len(a))


def sortedsd(dict1):
    retDict = {}
    list_keys = list(dict1.keys())
    list_keys.sort()
    for i in list_keys:
        retDict[i] = dict1[i]
    return retDict


value_mass = []
frequency = {}
df = pd.read_csv('8.csv')
for index, row in df.iterrows():
    d = row.to_dict()
    value_mass.append(d['W7_2015'])
    try:
        frequency[d['W7_2015']] += 1
    except KeyError:
        frequency[d['W7_2015']] = 1

frequency = sortedsd(frequency)
mas_count = []
mass_dict_value = []
for frq in frequency.keys():
    mass_dict_value.append(frq)
    mas_count.append(frequency[frq])


arithmetic_mean = np.mean(value_mass)
geometric_mean = geo_mean(value_mass)
harmonic_mean = s.harmonic_mean(value_mass)
median = s.median(value_mass)

print(
    f'Значения для: W7_2015\n'
    f'Среднее ариф: {arithmetic_mean}\n'
    f'Среднее геометр: {geometric_mean}\n'
    f'Среднее гармоническое: {harmonic_mean}\n'
    f'Медиана: {median}\n'
)

q1 = np.percentile(value_mass, 25)
q3 = np.percentile(value_mass, 75)

print(
    f'Значения для: W7_2015\n'
    f'Первый квартиль: {q1}\n'
    f'Третий квартиль: {q3}\n'
)

fig, ax = plt.subplots()
ax.scatter(arithmetic_mean, 10, c='red', label='Среднее арифмитическое')
ax.scatter(geometric_mean, 10, c='blue', label='Среднее геометрическое')
ax.scatter(harmonic_mean, 10, c='yellow', label='Среднее гармоническое')
ax.scatter(median, 10, c='black', label='Медиана')
ax.scatter(q1, 10, c='pink', label='Первый квартиль')
ax.scatter(q3, 10, c='deeppink', label='Третий квартиль')
ax.bar(mass_dict_value, mas_count)
ax.legend()
ax.set_title("Гистограмма частот")
plt.show()


accumulation_point = []
accumulation = 0
for point in mas_count:
    accumulation += point
    accumulation_point.append(accumulation)

fig, ax = plt.subplots()
ax.set_title("ОГИВА")
plt.plot(mass_dict_value, accumulation_point, 'o-r', alpha=0.7, label="first", lw=5, mec='b', mew=2, ms=10)
plt.show()


# максимальное значение минус минимальное
range_of_variation = mass_dict_value[-1] - mass_dict_value[0]
# расчет среднего квадр. отклонения
root_mean_square_deviation = np.std(mass_dict_value)
# Расчет дисперсии
dispersion = np.var(mass_dict_value)
# Коффициент вариации
coefficient_of_variation = abs(variation(mass_dict_value))
# интерквартильный  размах
interquartile = q3 - q1


print(
    f'Значения для: W7_2015\n'
    f'Размах вариации: {range_of_variation}\n'
    f'Среднее квадр. отклонения: {root_mean_square_deviation}\n'
    f'Дисперсия: {dispersion}\n'
    f'Коэффицент вариации: {coefficient_of_variation}\n'
    f'Интерквартильный  размах: {interquartile}')


plt.boxplot(frequency)
plt.show()

print(
    f'Показатель ассиметрии: {skew(mass_dict_value)}\n'
    f'Показатель эксцесса: {kurtosis(mass_dict_value)}'
)

import os
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn import preprocessing



value_mass = []
frequency = {}
df = pd.read_csv('8.csv')

# Чем больше значение переменной, тем лучше
def normalize(arr):
    normal_arr = np.array(arr)
    mini = normal_arr.min()
    maxi = normal_arr.max()
    for i in range(len(normal_arr)):
        normal_arr[i] = ((normal_arr[i] - mini) / (maxi - mini)) * 100
    return normal_arr


mass_all = {}
for index, row in df.iterrows():
    d = row.to_dict()
    for key in d:
        if key not in ['region_id', 'region']:
            try:
                mass_all[key].append(d[key])
            except KeyError:
                mass_all[key] = [d[key]]

normal_mass_all = {}
for key in mass_all:
    normal_mass_all[key] = normalize(mass_all[key])


# Вывод матрицы для нормализированных данных
myData = pd.DataFrame(normal_mass_all)
sns.heatmap(myData.corr(), annot=True)
plt.show()

# Вывод матрицы для не нормализированных
myDataBad = pd.DataFrame(mass_all)
sns.heatmap(myDataBad.corr(), annot=True)
plt.show()

# Кластерезация количественных показателей
scaler = preprocessing.StandardScaler().fit(myDataBad)
Ds = scaler.transform(myDataBad)
print(pd.DataFrame(Ds))
R = np.dot(np.transpose(Ds), Ds)/len(Ds)
print(pd.DataFrame(R))
eigh_val, eigh_vec = np.linalg.eigh(R)
print(pd.Series(eigh_val))
print(pd.DataFrame(eigh_vec))
print('Вклад каждой компоненты в общую изменчивость признаков (в %): ', [i/sum(eigh_val)*100 for i in eigh_val])
First=np.dot(Ds, eigh_vec[:,25])
Second=np.dot(Ds, eigh_vec[:,24])
print(pd.Series(First))
print(pd.Series(Second))
plt.scatter(x=First, y=Second, marker="h")

for i in range(len(First)):
    plt.annotate(df.iloc[i, 0], (First[i], Second[i]))

plt.show()


A=np.matrix([
    mass_all['W1_2014'],
    mass_all['W1_2015'],
    mass_all['W1_2016']
])

print(A)

print(pd.DataFrame(A).corr())
scaler = preprocessing.StandardScaler().fit(A)
print(scaler.mean_)
print(scaler.scale_)
B=np.matrix([
    mass_all['W2_2014'],
    mass_all['W2_2015'],
    mass_all['W2_2016']
])
print(B)

print(np.dot(np.transpose(B),B)/3)

